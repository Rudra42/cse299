<?php
include "connection.php";
if(isset($_GET['phone_num'])){
    //echo $_GET['id'];
    $delete_id=$_GET['phone_num'];
    
    $delete_sql= "DELETE FROM request where phone_num=$delete_id";
    if($conn->query( $delete_sql)){
        header("location:../admin.php");
    }
    else{
        die($conn->error);
    }
}
else{
    header("location:../admin.php");
}


if(isset($_GET['phone'])){
    //echo $_GET['id'];
    $delete_id=$_GET['phone'];
    
    $delete_sql= "DELETE FROM donor where phone=$delete_id";
    if($conn->query( $delete_sql)){
        header("location:../admin.php");
    }
    else{
        die($conn->error);
    }
}
else{
    header("location:../admin.php");
}
?>