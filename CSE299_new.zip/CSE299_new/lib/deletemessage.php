<?php
include "connection.php";
if(isset($_GET['phone_num'])){
    //echo $_GET['id'];
    $delete_id=$_GET['phone_num'];
    
    $delete_sql= "DELETE FROM message where phone_num=$delete_id";
    if($conn->query( $delete_sql)){
        header("location: messages.php");
    }
    else{
        die($conn->error);
    }
}
else{
    header("location: messages.php");
}
?>