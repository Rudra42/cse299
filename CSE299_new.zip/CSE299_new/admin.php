<?php 
    
    include "lib/connect.php";

    //select query
    $select_sql="SELECT * FROM request";
    $select_query=$conn->query($select_sql);

    $select_sql1="SELECT * FROM donor";
    $select_query1=$conn->query($select_sql1);

?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->

    <link href="https://fonts.googleapis.com/css?family=Dosis:400,700|Lato:300,400" rel="stylesheet">
    <link rel="icon" href="images/Fav_icon.jpg" type="image/gif" sizes="16x16">
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/media.css">
    <style>
        .button_home{
            margin: 0 auto;
            margin-top: 20px;
        }
    </style>

    <title>Blood for Life</title>
</head>

<body>
    <!--  Start From here  -->
    
    <!--    header start  -->
    <header>
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="admin.php"><img src="images/logo.png" alt="logo" class="img-fluid"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse custom_nav" id="navbarSupportedContent">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="admin.php">Admin Page</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="lib/messages.php">Messages</a>
                        </li>
                           <li class="nav-item">
                            <a class="nav-link" href="index.php">Log Out </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>
    <!--    header ends  -->

     <!--    banner part starts   -->
    <div class="container">
    <div class="row">
    <div class="col-md-12 banner">
    <span id="info2">All Requests</span>

    <div id="info3" class="col-md-12">
           
    <!--=====================
          Content
======================-->
        <section id="content">
            <div class="table table-dark">
                <table border="1" width=100%;>
                    <tr>
                        <th>Name</th>
                        <th>Blood Group</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Location</th>
<!--                        <th>Phone Number</th>-->
<!--                        <th>Action</th>-->
                    </tr>
                    <?php   if($select_query->num_rows>0){         ?>
                    <?php while($data=$select_query->fetch_assoc()){ ?>
                    <tr>
                        <th>
                            <?php echo $data['name'] ?>
                        </th>
                        <th>
                            <?php echo $data['bloodgroup'] ?>
                        </th>
                        <th>
                            <?php echo $data['mail'] ?>
                        </th>
                        <th>
                            <?php echo $data['phone_num'] ?>
                        </th>
                        <th>
                            <?php echo $data['location'] ?>
                        </th>

                        <td>
                            <a href="lib/delete.php?phone_num=<?php echo $data['phone_num'];  ?>">Delete</a>
                        </td>
                    </tr>

                    <?php } ?>
                    <?php } else{  ?>
                    <tr>
                        <td colspan="6">No Records Found!</td>
                    </tr>
                    <?php } ?>
                </table>
            </div>
        </section>
    </div>
      
    </div>
    </div>
</div>


 <div class="container">
    <div class="row">
    <div class="col-md-12 banner">
    <span id="info2">All Donors</span>

    <div id="info3" class="col-md-12">
           
    <!--=====================
          Content
======================-->
        <section id="content">
            <div class="table table-dark">
                <table border="1" width=100%;>
                    <tr>
                        <th>Name</th>
                        <th>Blood Group</th>
                        <th>Email</th>
                        <th>Phone Number</th>
                        <th>Location</th>
<!--                        <th>Phone Number</th>-->
<!--                        <th>Action</th>-->
                    </tr>
                    <?php   if($select_query1->num_rows>0){         ?>
                    <?php while($data=$select_query1->fetch_assoc()){ ?>
                    <tr>
                        <th>
                            <?php echo $data['full_name'] ?>
                        </th>
                        <th>
                            <?php echo $data['blood_group'] ?>
                        </th>
                        <th>
                            <?php echo $data['email'] ?>
                        </th>
                        <th>
                            <?php echo $data['phone'] ?>
                        </th>
                        <th>
                            <?php echo $data['address'] ?>
                        </th>

                        <td>
                            <a href="lib/delete.php?phone=<?php echo $data['phone'];  ?>">Delete</a>
                        </td>
                    </tr>

                    <?php } ?>
                    <?php } else{  ?>
                    <tr>
                        <td colspan="6">No Records Found!</td>
                    </tr>
                    <?php } ?>
                </table>
            </div>
        </section>
    </div>
      
    </div>
    </div>
</div>
        
        <!--    banner part ends   -->




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/app.js"></script>
</body>

</html>
